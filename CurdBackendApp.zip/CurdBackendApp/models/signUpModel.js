const mongoose = require('mongoose');

const signUpSchema = new mongoose.Schema({
    username: {
        type: String,
    //     required: true,
    //     minlength: 3, // Minimum length of 3 characters
    //     maxlength: 50, // Maximum length of 50 characters
    //     trim: true // Removes leading and trailing whitespace
    },
    email: {
        type: String,
       // required: true,
        // unique: true, // Ensures uniqueness
        // lowercase: true, // Converts email to lowercase
        // trim: true, // Removes leading and trailing whitespace
        // validate: {
        //     validator: function(value) {
        //         // Custom email format validation using regular expression
        //         return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
        //     },
          //  message: 'Invalid email format'
        }
    ,
    password: {
        type: String,
        // required: true,
        // minlength: 6, // Minimum length of 6 characters
        // maxlength: 50, // Maximum length of 50 characters
        // trim: true // Removes leading and trailing whitespace
    }
});

module.exports = mongoose.model("SignUp", signUpSchema);
