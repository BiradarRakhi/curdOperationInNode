const mongoose=require("mongoose");
const enquirySchema=mongoose.Schema({

})
module.exports=mongoose.model('enquiry',enquirySchema);