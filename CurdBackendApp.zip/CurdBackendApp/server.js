const express=require('express');
const app=express();
const routes=require('./routes/routes')

const mongoose=require('mongoose');

const cors=require('cors');

mongoURL= "mongodb+srv://biradarrakhi2001:urzo15jAgr1v0ZdE@cluster0.otnuj.mongodb.net/nodeDb?retryWrites=true&w=majority"
const status=mongoose.connect(mongoURL)
if(!status)
{
    console.log("connection faild!!!")
}
else
{
    console.log("mongodb connected successfully!!!");
}


app.use(cors());
app.use(express.json());
app.use(routes);

app.listen(3000,()=>{
    console.log("server is running on port 3000");
})