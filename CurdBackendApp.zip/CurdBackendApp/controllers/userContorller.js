

const userModel=require("../models/userModel")

const getDataControllerfn = async (req, res) => {
    try {
      const userId = req.params.userId;
      
      const user = await userModel.findById(userId);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      return res.status(200).json(user); 
    } catch (error) {
      console.error("Error fetching user data:", error);
      return res.status(500).json({ error: "Internal Server Error" });
    }
  }
  
const getAllDataControllerfn = async (req, res) => {
    try {
      const allUsers = await userModel.find();
      
      return res.status(200).json(allUsers); 
    } 
    catch (error) {
      console.error("Error fetching all users:", error);
      return res.status(500).json({ error: "Internal Server Error" });
    }
  }


// const createDataControllerfn =async(req,res)=>{
//   try{
//       const user=req.body;
//       const newUser=new userModel(user);
//       await newUser.save();
//       return res.status(201).json(newUser)

//   }
//   catch (error) {
//     console.error("Error fetching all users:", error);
//     return res.status(500).json(
//       { 
//         error: "Internal Server Error" 
//       });
//   }
// }


const createDataControllerfn = async (req, res) => {
  try {
      const user = req.body;
      const newUser = new userModel(user);
      await newUser.save();

      const allUsers = await userModel.find();

      allUsers.sort((a, b) => (a.name > b.name) ? 1 : -1);


      return res.status(201).json({ newUser, allUsers });

  } catch (error) {
      console.error("Error creating new user:", error);
      return res.status(500).json({ error: "Internal Server Error" });
  }
}


const updateDataControllerFn=async(req,res)=>{
  try{
     var userId=await req.params.id;
     const userData=req.body;
     const updateUser=await userModel.findByIdAndUpdate(userId,userData,
      {
        new:true
      })
      if (!updateUser) {
        return res.status(404).json({ error: "User not found" });
      }
      return res.status(200).json(updateUser);

  }
  catch (error) {
    console.error("Error fetching all users:", error);
    return res.status(500).json(
      { 
        error: "Internal Server Error" 
      });
  }

}

const deleteDataControllerFn = async (req, res) => {
  try {
    const userId = req.params.id;
    const deletedUser = await userModel.findByIdAndDelete(userId);
    if (!deletedUser) {
      return res.status(404).json({ error: "User not found" });
    }
    return res.status(200).json(deletedUser);
  } catch (error) {
    console.error("Error deleting user:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
}
module.exports={
    getAllDataControllerfn,
    updateDataControllerFn,
    getDataControllerfn,
    createDataControllerfn,
    deleteDataControllerFn
}