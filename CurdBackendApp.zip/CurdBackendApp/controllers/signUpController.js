const SignUp = require('../models/signUpModel');

const signUpCr = 
 async (req, res) => {
    try {
      const existingUser = await SignUp.findOne({ email: req.body.email });
      if (existingUser) {
        return res.status(400).json({ error: 'Email already exists' });
      }

      const newUser = new SignUp({
        username: req.body.username,
        email: req.body.email,
        password: req.body.password
      });

      await newUser.save();
      res.status(201).json(newUser);
    } catch (error) {
      console.error('Error signing up user:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }

 const loginCr= async (req, res) => {
    try {
      const { email, password } = req.body;

      const user = await SignUp.findOne({ email });

      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      const isValidPassword = await user.comparePassword(password);
      if (!isValidPassword) {
        return res.status(401).json({ error: 'Invalid password' });
      }

      res.status(200).json({ message: 'Login successful', user });
    } catch (error) {
      console.error('Error logging in user:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  };



module.exports = {
  loginCr,
  signUpCr
};
