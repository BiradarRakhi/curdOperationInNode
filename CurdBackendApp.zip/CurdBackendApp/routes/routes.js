

const userContorller=require('../controllers/userContorller');

const express=require('express');
const router=express.Router();
router.route('/user/getAll').get(userContorller.getAllDataControllerfn);
router.route('/user/getOne/:id').get(userContorller.getAllDataControllerfn);
router.route('/user/create').post(userContorller.createDataControllerfn);
router.route('/user/update/:id').patch(userContorller.updateDataControllerFn);
router.route('/user/delete/:id').delete(userContorller.deleteDataControllerFn);

const signUpController = require('../controllers/signUpController');
router.route('/user/login').post(signUpController.loginCr);
router.route('/user/signUp').post(signUpController.signUpCr);


const enquiryController=require('../controllers/enquiryController');
router.route('/user/')

module.exports=router;